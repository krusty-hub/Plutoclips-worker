"""
FastAPI route handlers for all API endpoints.

Implements:
- Health checks
- Video upload
- Job status tracking
- Clip retrieval
- File downloads
"""

import logging
import os
from pathlib import Path
from typing import Optional

from fastapi import (
    APIRouter,
    File,
    UploadFile,
    HTTPException,
    BackgroundTasks,
    Response,
    Header,
)
from fastapi.responses import FileResponse, StreamingResponse

from app.core.config import settings
from app.core.exceptions import PlutoClipsException
from app.schemas import (
    UploadVideoResponse,
    ProcessVideoRequest,
    ProcessVideoResponse,
    JobStatusResponse,
    ClipsResponse,
    ErrorResponse,
)
from app.services.video import VideoProcessingService
from app.core.logger import get_logger

logger = get_logger(__name__)

router = APIRouter(tags=["videos"])

# Initialize service
video_service = VideoProcessingService()


# ============================================================================
# Health Check
# ============================================================================

@router.get("/health", response_model=dict)
async def health_check():
    """
    Health check endpoint.
    
    Returns:
        Status indicator
    """
    return {"status": "ok"}


# ============================================================================
# Upload Endpoint
# ============================================================================

@router.post("/upload", response_model=UploadVideoResponse)
async def upload_video(
    file: UploadFile = File(...),
) -> UploadVideoResponse:
    """
    Upload a video file for processing.
    
    Validates file type and size, stores file, and creates job record.
    
    Args:
        file: Video file (multipart/form-data)
        
    Returns:
        UploadVideoResponse with job_id and status
        
    Raises:
        HTTPException: If validation fails
    """
    try:
        # Validate file type
        if not file.filename:
            raise HTTPException(
                status_code=400,
                detail="Filename is required"
            )
        
        # Validate extension
        allowed_extensions = {".mp4", ".avi", ".mov", ".mkv", ".flv", ".webm", ".m4v"}
        file_ext = Path(file.filename).suffix.lower()
        
        if file_ext not in allowed_extensions:
            raise HTTPException(
                status_code=400,
                detail=f"File type not supported. Allowed: {', '.join(allowed_extensions)}"
            )
        
        # Validate file size
        content_length = file.size or 0
        max_size_bytes = settings.MAX_UPLOAD_SIZE_MB * 1024 * 1024
        
        if content_length > max_size_bytes:
            raise HTTPException(
                status_code=413,
                detail=f"File too large. Maximum size: {settings.MAX_UPLOAD_SIZE_MB}MB"
            )
        
        # Sanitize filename
        import hashlib
        file_hash = hashlib.md5(file.filename.encode()).hexdigest()[:8]
        safe_filename = f"{file_hash}_{Path(file.filename).stem}{file_ext}"
        
        # Save file
        upload_dir = Path(settings.UPLOAD_DIR)
        upload_dir.mkdir(parents=True, exist_ok=True)
        
        file_path = upload_dir / safe_filename
        
        # Read and save file
        contents = await file.read()
        with open(file_path, 'wb') as f:
            f.write(contents)
        
        # Create job
        job_id = video_service.create_job(
            original_filename=file.filename,
            file_path=str(file_path)
        )
        
        logger.info(f"✓ File uploaded: {file.filename} -> {job_id}")
        
        return UploadVideoResponse(
            job_id=job_id,
            status="uploaded",
            message="Video uploaded successfully"
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Upload error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Upload failed: {str(e)}"
        )


# ============================================================================
# Processing
# ============================================================================

@router.post("/process-video", response_model=ProcessVideoResponse)
async def process_video(
    request: ProcessVideoRequest,
    background_tasks: BackgroundTasks
) -> ProcessVideoResponse:
    """
    Start video processing for an uploaded video.
    
    Starts background task to process video asynchronously.
    Use /job-status endpoint to check progress.
    
    Args:
        request: ProcessVideoRequest with job_id
        background_tasks: FastAPI background tasks
        
    Returns:
        ProcessVideoResponse with job status
        
    Raises:
        HTTPException: If job not found or processing fails
    """
    try:
        # Verify job exists
        job = video_service.get_job_status(request.job_id)
        
        # Add processing task to background
        background_tasks.add_task(
            video_service.process_video,
            request.job_id
        )
        
        logger.info(f"Started processing: {request.job_id}")
        
        return ProcessVideoResponse(
            job_id=request.job_id,
            status="processing",
            message="Processing started"
        )
        
    except Exception as e:
        logger.error(f"Processing start error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Failed to start processing: {str(e)}"
        )


# ============================================================================
# Status Endpoint
# ============================================================================

@router.get("/job-status/{job_id}", response_model=JobStatusResponse)
async def get_job_status(job_id: str) -> JobStatusResponse:
    """
    Get current status of a processing job.
    
    Args:
        job_id: Job identifier
        
    Returns:
        JobStatusResponse with current status and progress
        
    Raises:
        HTTPException: If job not found
    """
    try:
        job = video_service.get_job_status(job_id)
        
        return JobStatusResponse(
            job_id=job_id,
            status=job["status"],
            progress=job.get("progress", 0),
            error=job.get("error"),
            created_at=job["created_at"],
            updated_at=job["updated_at"]
        )
        
    except Exception as e:
        logger.error(f"Status check error: {e}")
        raise HTTPException(
            status_code=404,
            detail=f"Job not found: {job_id}"
        )


# ============================================================================
# Results Endpoint
# ============================================================================

@router.get("/clips/{job_id}", response_model=ClipsResponse)
async def get_clips(job_id: str) -> ClipsResponse:
    """
    Get all generated clips for a completed job.
    
    Args:
        job_id: Job identifier
        
    Returns:
        ClipsResponse with list of generated clips
        
    Raises:
        HTTPException: If job not found or not completed
    """
    try:
        result = video_service.get_clips(job_id)
        
        return ClipsResponse(
            job_id=result["job_id"],
            status=result["status"],
            total_clips=result["total_clips"],
            clips=result["clips"],
            video_duration=result.get("video_duration", 0),
            processing_time=0  # Calculate if needed
        )
        
    except Exception as e:
        logger.error(f"Get clips error: {e}")
        raise HTTPException(
            status_code=404,
            detail=f"Unable to retrieve clips: {str(e)}"
        )


# ============================================================================
# Download Endpoint
# ============================================================================

@router.get("/download/{file_path:path}")
async def download_file(file_path: str) -> FileResponse:
    """
    Download a generated clip, caption, or thumbnail.
    
    Args:
        file_path: Relative path to file (from outputs directory)
        
    Returns:
        FileResponse with file content
        
    Raises:
        HTTPException: If file not found
    """
    try:
        # Construct full path safely
        full_path = Path(settings.OUTPUT_DIR) / file_path
        
        # Security: ensure path is within outputs directory
        full_path = full_path.resolve()
        output_dir = Path(settings.OUTPUT_DIR).resolve()
        
        if not str(full_path).startswith(str(output_dir)):
            raise HTTPException(
                status_code=403,
                detail="Access denied"
            )
        
        if not full_path.exists():
            raise HTTPException(
                status_code=404,
                detail=f"File not found: {file_path}"
            )
        
        # Determine media type
        media_type = "application/octet-stream"
        if full_path.suffix.lower() == ".mp4":
            media_type = "video/mp4"
        elif full_path.suffix.lower() == ".srt":
            media_type = "text/plain"
        elif full_path.suffix.lower() in [".jpg", ".jpeg"]:
            media_type = "image/jpeg"
        elif full_path.suffix.lower() == ".png":
            media_type = "image/png"
        
        return FileResponse(
            path=full_path,
            media_type=media_type,
            filename=full_path.name
        )
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Download error: {e}")
        raise HTTPException(
            status_code=500,
            detail=f"Download failed: {str(e)}"
        )


# ============================================================================
# Error Handler
# ============================================================================

@router.get("/error-example", include_in_schema=False)
async def error_example():
    """Example endpoint showing error handling."""
    raise HTTPException(
        status_code=400,
        detail="Example error"
    )
