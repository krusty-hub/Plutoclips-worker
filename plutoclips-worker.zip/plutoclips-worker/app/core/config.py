"""
Configuration module for PlutoClips Worker.

Handles environment variables, validation, and settings management
using Pydantic for type safety and validation.
"""

from pydantic_settings import BaseSettings
from pydantic import Field
from typing import Literal


class Settings(BaseSettings):
    """
    Application settings loaded from environment variables.
    
    Attributes:
        ENVIRONMENT: Development or production environment
        LOG_LEVEL: Logging verbosity level
        OPENAI_API_KEY: OpenAI API key for Whisper transcription and GPT
        ANTHROPIC_API_KEY: Anthropic Claude API key for AI analysis
        MAX_UPLOAD_SIZE_MB: Maximum file upload size in MB
        UPLOAD_DIR: Directory to store uploaded videos
        OUTPUT_DIR: Directory to store processed output files
        ALLOWED_ORIGINS: CORS allowed origins (comma-separated)
        WORKER_BASE_URL: Base URL for worker service (for callbacks)
        DATABASE_URL: SQLite database URL
        SQLITE_DB_PATH: Path to SQLite database file
    """
    
    # Environment
    ENVIRONMENT: Literal["development", "production"] = Field(
        default="development",
        description="Deployment environment"
    )
    LOG_LEVEL: Literal["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"] = Field(
        default="INFO",
        description="Logging level"
    )
    
    # API Keys
    OPENAI_API_KEY: str = Field(
        default="",
        description="OpenAI API key"
    )
    ANTHROPIC_API_KEY: str = Field(
        default="",
        description="Anthropic Claude API key"
    )
    
    # File Upload Settings
    MAX_UPLOAD_SIZE_MB: int = Field(
        default=500,
        description="Maximum file upload size in MB"
    )
    UPLOAD_DIR: str = Field(
        default="uploads",
        description="Directory for uploaded files"
    )
    OUTPUT_DIR: str = Field(
        default="outputs",
        description="Directory for output files"
    )
    
    # Network Settings
    ALLOWED_ORIGINS: str = Field(
        default="*",
        description="CORS allowed origins (comma-separated or *)"
    )
    WORKER_BASE_URL: str = Field(
        default="http://localhost:8000",
        description="Base URL for worker service"
    )
    
    # Database Settings
    SQLITE_DB_PATH: str = Field(
        default="plutoclips.db",
        description="Path to SQLite database file"
    )
    
    @property
    def DATABASE_URL(self) -> str:
        """Generate SQLite database URL."""
        return f"sqlite:///{self.SQLITE_DB_PATH}"
    
    # Video Processing Settings
    MIN_CLIP_DURATION: int = Field(
        default=20,
        description="Minimum clip duration in seconds"
    )
    MAX_CLIP_DURATION: int = Field(
        default=90,
        description="Maximum clip duration in seconds"
    )
    TARGET_CLIP_COUNT: int = Field(
        default=7,
        description="Target number of clips to generate"
    )
    MIN_CLIP_COUNT: int = Field(
        default=5,
        description="Minimum number of clips to generate"
    )
    MAX_CLIP_COUNT: int = Field(
        default=10,
        description="Maximum number of clips to generate"
    )
    
    # Processing Settings
    VIDEO_CODEC: str = Field(
        default="libx264",
        description="FFmpeg video codec"
    )
    AUDIO_CODEC: str = Field(
        default="aac",
        description="FFmpeg audio codec"
    )
    VIDEO_BITRATE: str = Field(
        default="2500k",
        description="Output video bitrate"
    )
    AUDIO_BITRATE: str = Field(
        default="128k",
        description="Output audio bitrate"
    )
    
    # Timeout Settings
    TRANSCRIPTION_TIMEOUT: int = Field(
        default=600,
        description="Transcription timeout in seconds (10 minutes)"
    )
    AI_ANALYSIS_TIMEOUT: int = Field(
        default=120,
        description="AI analysis timeout in seconds"
    )
    CLIP_GENERATION_TIMEOUT: int = Field(
        default=300,
        description="Clip generation timeout in seconds (5 minutes)"
    )
    
    class Config:
        """Pydantic configuration."""
        env_file = ".env"
        case_sensitive = True


# Singleton settings instance
settings = Settings()
