"""
Custom exception classes for PlutoClips Worker.

Provides domain-specific exceptions for better error handling and
HTTP status code mapping.
"""

from typing import Optional


class PlutoClipsException(Exception):
    """Base exception for all PlutoClips-specific errors."""
    
    def __init__(
        self,
        message: str,
        status_code: int = 500,
        detail: Optional[str] = None,
    ):
        """
        Initialize exception.
        
        Args:
            message: Human-readable error message
            status_code: HTTP status code
            detail: Additional error details
        """
        self.message = message
        self.status_code = status_code
        self.detail = detail or message
        super().__init__(self.message)


class ValidationError(PlutoClipsException):
    """Raised when input validation fails."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=400, detail=detail)


class FileUploadError(PlutoClipsException):
    """Raised when file upload fails."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=400, detail=detail)


class VideoProcessingError(PlutoClipsException):
    """Raised when video processing fails."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=422, detail=detail)


class TranscriptionError(PlutoClipsException):
    """Raised when transcription fails."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=422, detail=detail)


class AIAnalysisError(PlutoClipsException):
    """Raised when AI analysis fails."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=422, detail=detail)


class ClipGenerationError(PlutoClipsException):
    """Raised when clip generation fails."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=422, detail=detail)


class ResourceNotFoundError(PlutoClipsException):
    """Raised when a resource is not found."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=404, detail=detail)


class ConfigurationError(PlutoClipsException):
    """Raised when configuration is invalid or missing."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=500, detail=detail)


class TimeoutError(PlutoClipsException):
    """Raised when operation times out."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=408, detail=detail)


class StorageError(PlutoClipsException):
    """Raised when storage operation fails."""
    
    def __init__(self, message: str, detail: Optional[str] = None):
        super().__init__(message, status_code=500, detail=detail)
