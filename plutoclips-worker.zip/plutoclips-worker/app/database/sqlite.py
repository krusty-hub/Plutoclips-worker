"""
SQLite database initialization and ORM models.

Provides database setup and models for jobs, clips, and processing history.
Designed to support migration to PostgreSQL without code changes.
"""

import sqlite3
import json
from pathlib import Path
from datetime import datetime
from typing import Optional, List, Dict, Any

from app.core.config import settings
from app.core.logger import get_logger

logger = get_logger(__name__)


def init_database() -> None:
    """
    Initialize SQLite database with required tables.
    
    Creates tables if they don't exist. This function is idempotent
    and safe to call multiple times.
    """
    db_path = Path(settings.SQLITE_DB_PATH)
    
    # Create database file if it doesn't exist
    if not db_path.exists():
        logger.info(f"Creating new database: {db_path}")
    
    conn = sqlite3.connect(str(db_path))
    cursor = conn.cursor()
    
    try:
        # Jobs table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS jobs (
                id TEXT PRIMARY KEY,
                status TEXT NOT NULL,
                original_filename TEXT NOT NULL,
                file_path TEXT NOT NULL,
                video_duration REAL,
                error TEXT,
                progress INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                completed_at TEXT
            )
        """)
        
        # Clips table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS clips (
                id TEXT PRIMARY KEY,
                job_id TEXT NOT NULL,
                clip_index INTEGER NOT NULL,
                title TEXT NOT NULL,
                seo_title TEXT NOT NULL,
                reason TEXT NOT NULL,
                moment_type TEXT NOT NULL,
                start_time REAL NOT NULL,
                end_time REAL NOT NULL,
                duration REAL NOT NULL,
                file_path TEXT,
                captions_path TEXT,
                thumbnail_path TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (job_id) REFERENCES jobs (id)
            )
        """)
        
        # Transcripts table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS transcripts (
                id TEXT PRIMARY KEY,
                job_id TEXT NOT NULL UNIQUE,
                language TEXT DEFAULT 'en',
                full_text TEXT NOT NULL,
                segments_json TEXT NOT NULL,
                duration REAL NOT NULL,
                created_at TEXT NOT NULL,
                FOREIGN KEY (job_id) REFERENCES jobs (id)
            )
        """)
        
        # Processing history table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS processing_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                job_id TEXT NOT NULL,
                step TEXT NOT NULL,
                status TEXT NOT NULL,
                error_message TEXT,
                duration_seconds REAL,
                timestamp TEXT NOT NULL,
                FOREIGN KEY (job_id) REFERENCES jobs (id)
            )
        """)
        
        conn.commit()
        logger.info("✓ Database tables initialized successfully")
        
    except sqlite3.Error as e:
        logger.error(f"Database initialization error: {e}")
        raise
    finally:
        conn.close()


def get_db_connection() -> sqlite3.Connection:
    """
    Get a connection to the SQLite database.
    
    Returns:
        sqlite3.Connection: Database connection
    """
    conn = sqlite3.connect(str(settings.SQLITE_DB_PATH))
    conn.row_factory = sqlite3.Row
    return conn


# ============================================================================
# Database Operations - Jobs
# ============================================================================

class JobRepository:
    """Repository for job-related database operations."""
    
    @staticmethod
    def create_job(
        job_id: str,
        original_filename: str,
        file_path: str,
        status: str = "uploaded"
    ) -> None:
        """
        Create a new job record.
        
        Args:
            job_id: Unique job identifier
            original_filename: Original uploaded filename
            file_path: Path to uploaded video file
            status: Initial job status
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        now = datetime.utcnow().isoformat()
        
        cursor.execute("""
            INSERT INTO jobs (id, status, original_filename, file_path, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (job_id, status, original_filename, file_path, now, now))
        
        conn.commit()
        conn.close()
        logger.info(f"Created job: {job_id}")
    
    @staticmethod
    def get_job(job_id: str) -> Optional[Dict[str, Any]]:
        """
        Get job by ID.
        
        Args:
            job_id: Job identifier
            
        Returns:
            Job record as dictionary or None if not found
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM jobs WHERE id = ?", (job_id,))
        row = cursor.fetchone()
        conn.close()
        
        return dict(row) if row else None
    
    @staticmethod
    def update_job_status(
        job_id: str,
        status: str,
        progress: int = None,
        error: str = None,
        video_duration: float = None
    ) -> None:
        """
        Update job status and metadata.
        
        Args:
            job_id: Job identifier
            status: New status
            progress: Progress percentage (0-100)
            error: Error message if failed
            video_duration: Video duration in seconds
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        now = datetime.utcnow().isoformat()
        updates = {"status": status, "updated_at": now}
        
        if progress is not None:
            updates["progress"] = progress
        if error is not None:
            updates["error"] = error
        if video_duration is not None:
            updates["video_duration"] = video_duration
        
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [job_id]
        
        cursor.execute(f"UPDATE jobs SET {set_clause} WHERE id = ?", values)
        conn.commit()
        conn.close()
        
        logger.info(f"Updated job {job_id}: {status}")
    
    @staticmethod
    def mark_job_completed(job_id: str) -> None:
        """
        Mark job as completed.
        
        Args:
            job_id: Job identifier
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        now = datetime.utcnow().isoformat()
        cursor.execute("""
            UPDATE jobs 
            SET status = 'completed', progress = 100, updated_at = ?, completed_at = ?
            WHERE id = ?
        """, (now, now, job_id))
        
        conn.commit()
        conn.close()
    
    @staticmethod
    def mark_job_failed(job_id: str, error: str) -> None:
        """
        Mark job as failed with error message.
        
        Args:
            job_id: Job identifier
            error: Error message
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        now = datetime.utcnow().isoformat()
        cursor.execute("""
            UPDATE jobs 
            SET status = 'failed', error = ?, updated_at = ?
            WHERE id = ?
        """, (error, now, job_id))
        
        conn.commit()
        conn.close()


# ============================================================================
# Database Operations - Clips
# ============================================================================

class ClipRepository:
    """Repository for clip-related database operations."""
    
    @staticmethod
    def create_clip(
        clip_id: str,
        job_id: str,
        clip_index: int,
        title: str,
        seo_title: str,
        reason: str,
        moment_type: str,
        start_time: float,
        end_time: float,
        duration: float,
        file_path: str = None,
        captions_path: str = None,
        thumbnail_path: str = None
    ) -> None:
        """
        Create a new clip record.
        
        Args:
            clip_id: Unique clip identifier
            job_id: Parent job ID
            clip_index: Index of clip in the job
            title: Viral title
            seo_title: SEO-optimized title
            reason: Why this is a viral moment
            moment_type: Type of moment (viral, funny, etc.)
            start_time: Start time in seconds
            end_time: End time in seconds
            duration: Clip duration
            file_path: Path to clip video file
            captions_path: Path to captions SRT file
            thumbnail_path: Path to thumbnail image
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        now = datetime.utcnow().isoformat()
        
        cursor.execute("""
            INSERT INTO clips 
            (id, job_id, clip_index, title, seo_title, reason, moment_type, 
             start_time, end_time, duration, file_path, captions_path, thumbnail_path, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            clip_id, job_id, clip_index, title, seo_title, reason, moment_type,
            start_time, end_time, duration, file_path, captions_path, thumbnail_path, now
        ))
        
        conn.commit()
        conn.close()
    
    @staticmethod
    def get_clips_by_job(job_id: str) -> List[Dict[str, Any]]:
        """
        Get all clips for a job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            List of clip records
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM clips WHERE job_id = ? ORDER BY clip_index
        """, (job_id,))
        
        rows = cursor.fetchall()
        conn.close()
        
        return [dict(row) for row in rows]
    
    @staticmethod
    def update_clip_paths(
        clip_id: str,
        file_path: str = None,
        captions_path: str = None,
        thumbnail_path: str = None
    ) -> None:
        """
        Update file paths for a clip.
        
        Args:
            clip_id: Clip identifier
            file_path: Path to video file
            captions_path: Path to captions file
            thumbnail_path: Path to thumbnail file
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        updates = {}
        if file_path:
            updates["file_path"] = file_path
        if captions_path:
            updates["captions_path"] = captions_path
        if thumbnail_path:
            updates["thumbnail_path"] = thumbnail_path
        
        if not updates:
            return
        
        set_clause = ", ".join([f"{k} = ?" for k in updates.keys()])
        values = list(updates.values()) + [clip_id]
        
        cursor.execute(f"UPDATE clips SET {set_clause} WHERE id = ?", values)
        conn.commit()
        conn.close()


# ============================================================================
# Database Operations - Transcripts
# ============================================================================

class TranscriptRepository:
    """Repository for transcript-related database operations."""
    
    @staticmethod
    def create_transcript(
        transcript_id: str,
        job_id: str,
        full_text: str,
        segments: List[Dict[str, Any]],
        duration: float,
        language: str = "en"
    ) -> None:
        """
        Create a new transcript record.
        
        Args:
            transcript_id: Unique transcript identifier
            job_id: Parent job ID
            full_text: Complete transcript text
            segments: List of transcript segments with timing
            duration: Video duration
            language: Detected language code
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        now = datetime.utcnow().isoformat()
        segments_json = json.dumps(segments)
        
        cursor.execute("""
            INSERT INTO transcripts 
            (id, job_id, language, full_text, segments_json, duration, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (transcript_id, job_id, language, full_text, segments_json, duration, now))
        
        conn.commit()
        conn.close()
    
    @staticmethod
    def get_transcript(job_id: str) -> Optional[Dict[str, Any]]:
        """
        Get transcript for a job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            Transcript record or None if not found
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("SELECT * FROM transcripts WHERE job_id = ?", (job_id,))
        row = cursor.fetchone()
        conn.close()
        
        if row:
            result = dict(row)
            result["segments"] = json.loads(result["segments_json"])
            return result
        
        return None


# ============================================================================
# Database Operations - Processing History
# ============================================================================

class ProcessingHistoryRepository:
    """Repository for processing history tracking."""
    
    @staticmethod
    def log_step(
        job_id: str,
        step: str,
        status: str,
        duration_seconds: float = None,
        error_message: str = None
    ) -> None:
        """
        Log a processing step.
        
        Args:
            job_id: Job identifier
            step: Processing step name
            status: Step status (started, completed, failed)
            duration_seconds: Duration of the step
            error_message: Error message if step failed
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        now = datetime.utcnow().isoformat()
        
        cursor.execute("""
            INSERT INTO processing_history 
            (job_id, step, status, duration_seconds, error_message, timestamp)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (job_id, step, status, duration_seconds, error_message, now))
        
        conn.commit()
        conn.close()
    
    @staticmethod
    def get_history(job_id: str) -> List[Dict[str, Any]]:
        """
        Get processing history for a job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            List of processing history records
        """
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute("""
            SELECT * FROM processing_history WHERE job_id = ? ORDER BY timestamp
        """, (job_id,))
        
        rows = cursor.fetchall()
        conn.close()
        
        return [dict(row) for row in rows]
