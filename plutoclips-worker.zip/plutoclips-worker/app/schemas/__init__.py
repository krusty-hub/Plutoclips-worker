"""
Pydantic models for API request/response schemas.

Provides type-safe data validation and serialization for all
API endpoints.
"""

from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime
from enum import Enum


class JobStatusEnum(str, Enum):
    """Job status enumeration."""
    UPLOADED = "uploaded"
    PROCESSING = "processing"
    TRANSCRIBING = "transcribing"
    ANALYZING = "analyzing"
    GENERATING = "generating"
    COMPLETED = "completed"
    FAILED = "failed"


class ClipMomentTypeEnum(str, Enum):
    """Type of clip moment detected."""
    ENGAGING = "engaging"
    FUNNY = "funny"
    EDUCATIONAL = "educational"
    EMOTIONAL = "emotional"
    SURPRISING = "surprising"
    VIRAL = "viral"


# ============================================================================
# Upload and Job Management
# ============================================================================

class UploadVideoResponse(BaseModel):
    """Response model for video upload."""
    job_id: str = Field(..., description="Unique job identifier")
    status: JobStatusEnum = Field(default=JobStatusEnum.UPLOADED, description="Job status")
    message: str = Field(default="Video uploaded successfully", description="Status message")
    
    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "uploaded",
                "message": "Video uploaded successfully"
            }
        }


class ProcessVideoRequest(BaseModel):
    """Request model for video processing."""
    job_id: str = Field(..., description="Job ID to process")
    
    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000"
            }
        }


class ProcessVideoResponse(BaseModel):
    """Response model for processing request."""
    job_id: str = Field(..., description="Job ID")
    status: JobStatusEnum = Field(default=JobStatusEnum.PROCESSING, description="Job status")
    message: str = Field(default="Processing started", description="Status message")
    
    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "processing",
                "message": "Processing started"
            }
        }


class JobStatusResponse(BaseModel):
    """Response model for job status check."""
    job_id: str = Field(..., description="Job ID")
    status: JobStatusEnum = Field(..., description="Current job status")
    progress: int = Field(default=0, ge=0, le=100, description="Progress percentage")
    error: Optional[str] = Field(default=None, description="Error message if failed")
    created_at: datetime = Field(..., description="Job creation timestamp")
    updated_at: datetime = Field(..., description="Last update timestamp")
    
    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "processing",
                "progress": 45,
                "error": None,
                "created_at": "2024-01-15T10:30:00Z",
                "updated_at": "2024-01-15T10:35:00Z"
            }
        }


# ============================================================================
# Clip Metadata
# ============================================================================

class ClipMetadata(BaseModel):
    """Metadata for a single generated clip."""
    title: str = Field(..., description="AI-generated viral title")
    seo_title: str = Field(..., description="SEO-optimized title")
    reason: str = Field(..., description="Why this moment is viral-worthy")
    moment_type: ClipMomentTypeEnum = Field(..., description="Type of clip moment")
    start_time: float = Field(..., ge=0, description="Clip start time in seconds")
    end_time: float = Field(..., ge=0, description="Clip end time in seconds")
    duration: float = Field(..., ge=0, description="Clip duration in seconds")
    
    class Config:
        json_schema_extra = {
            "example": {
                "title": "Mind-Blowing AI Breakthrough That Changed Everything",
                "seo_title": "AI Breakthrough 2024 | Game-Changing Technology",
                "reason": "Unexpected revelation about AI capabilities that sparks curiosity",
                "moment_type": "viral",
                "start_time": 120.5,
                "end_time": 175.2,
                "duration": 54.7
            }
        }


class ClipFile(BaseModel):
    """Information about a processed clip file."""
    clip_id: str = Field(..., description="Unique clip identifier")
    title: str = Field(..., description="Clip title")
    url: str = Field(..., description="URL to download clip video")
    duration: float = Field(..., ge=0, description="Clip duration in seconds")
    thumbnail_url: Optional[str] = Field(default=None, description="URL to clip thumbnail")
    captions_url: Optional[str] = Field(default=None, description="URL to SRT captions file")
    moment_type: ClipMomentTypeEnum = Field(..., description="Type of moment")
    reason: str = Field(..., description="Why this is a viral moment")
    
    class Config:
        json_schema_extra = {
            "example": {
                "clip_id": "clip_001",
                "title": "Mind-Blowing AI Breakthrough That Changed Everything",
                "url": "/api/v1/download/clip_001.mp4",
                "duration": 54.7,
                "thumbnail_url": "/api/v1/download/clip_001_thumb.jpg",
                "captions_url": "/api/v1/download/clip_001.srt",
                "moment_type": "viral",
                "reason": "Unexpected revelation about AI capabilities"
            }
        }


class ClipsResponse(BaseModel):
    """Response model containing all generated clips."""
    job_id: str = Field(..., description="Job ID")
    status: JobStatusEnum = Field(..., description="Job status")
    total_clips: int = Field(..., ge=0, description="Total number of clips generated")
    clips: List[ClipFile] = Field(default_factory=list, description="List of generated clips")
    video_duration: float = Field(..., ge=0, description="Original video duration in seconds")
    processing_time: float = Field(..., ge=0, description="Total processing time in seconds")
    
    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "status": "completed",
                "total_clips": 7,
                "clips": [
                    {
                        "clip_id": "clip_001",
                        "title": "Mind-Blowing AI Breakthrough",
                        "url": "/api/v1/download/clip_001.mp4",
                        "duration": 54.7,
                        "thumbnail_url": "/api/v1/download/clip_001_thumb.jpg",
                        "captions_url": "/api/v1/download/clip_001.srt",
                        "moment_type": "viral",
                        "reason": "Unexpected revelation"
                    }
                ],
                "video_duration": 3600.0,
                "processing_time": 125.5
            }
        }


# ============================================================================
# Transcription and Analysis
# ============================================================================

class TranscriptSegment(BaseModel):
    """A segment of transcribed text with timing."""
    start: float = Field(..., ge=0, description="Start time in seconds")
    end: float = Field(..., ge=0, description="End time in seconds")
    text: str = Field(..., description="Transcribed text")
    confidence: float = Field(default=1.0, ge=0, le=1, description="Confidence score")
    
    class Config:
        json_schema_extra = {
            "example": {
                "start": 0.0,
                "end": 3.5,
                "text": "Hello everyone, welcome back to the channel",
                "confidence": 0.98
            }
        }


class TranscriptResponse(BaseModel):
    """Response model for transcript."""
    job_id: str = Field(..., description="Job ID")
    language: str = Field(default="en", description="Detected language")
    segments: List[TranscriptSegment] = Field(..., description="Transcript segments")
    full_text: str = Field(..., description="Complete transcript text")
    duration: float = Field(..., ge=0, description="Video duration in seconds")
    
    class Config:
        json_schema_extra = {
            "example": {
                "job_id": "550e8400-e29b-41d4-a716-446655440000",
                "language": "en",
                "segments": [
                    {
                        "start": 0.0,
                        "end": 3.5,
                        "text": "Hello everyone",
                        "confidence": 0.98
                    }
                ],
                "full_text": "Hello everyone welcome to the channel",
                "duration": 3600.0
            }
        }


# ============================================================================
# Error Responses
# ============================================================================

class ErrorResponse(BaseModel):
    """Standard error response model."""
    status: str = Field(default="error", description="Status indicator")
    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    detail: Optional[str] = Field(default=None, description="Additional error details")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "error",
                "error": "VideoProcessingError",
                "message": "Failed to process video",
                "detail": "FFmpeg returned error code 1"
            }
        }


# ============================================================================
# Health Check
# ============================================================================

class HealthCheckResponse(BaseModel):
    """Health check response model."""
    status: str = Field(default="ok", description="Service status")
    version: str = Field(..., description="Service version")
    
    class Config:
        json_schema_extra = {
            "example": {
                "status": "ok",
                "version": "0.1.0"
            }
        }
