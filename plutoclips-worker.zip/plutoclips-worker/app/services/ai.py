"""
AI services for transcription and clip detection.

Integrates with OpenAI (Whisper, GPT) and Anthropic (Claude) for
transcription, analysis, and clip moment detection.
"""

import json
import logging
from typing import List, Dict, Any, Optional
import asyncio

from app.core.config import settings
from app.core.exceptions import (
    ConfigurationError,
    TranscriptionError,
    AIAnalysisError,
)

logger = logging.getLogger(__name__)


class TranscriptionService:
    """
    Service for audio transcription using OpenAI Whisper API.
    """
    
    def __init__(self):
        """Initialize transcription service."""
        if not settings.OPENAI_API_KEY:
            raise ConfigurationError(
                "OpenAI API key not configured",
                detail="Set OPENAI_API_KEY environment variable"
            )
        
        try:
            import openai
            self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
        except ImportError:
            raise ConfigurationError(
                "openai library not installed",
                detail="Run: pip install openai"
            )
    
    def transcribe_audio(self, audio_path: str, language: str = "en") -> Dict[str, Any]:
        """
        Transcribe audio file using OpenAI Whisper.
        
        Args:
            audio_path: Path to audio file
            language: Language code (e.g., 'en', 'es', 'fr')
            
        Returns:
            Dictionary with transcript data:
            {
                "text": "Full transcription",
                "segments": [
                    {
                        "start": 0.0,
                        "end": 3.5,
                        "text": "Segment text",
                        "confidence": 0.98
                    }
                ]
            }
            
        Raises:
            TranscriptionError: If transcription fails
        """
        try:
            logger.info(f"Starting transcription: {audio_path}")
            
            with open(audio_path, 'rb') as audio_file:
                transcript = self.client.audio.transcriptions.create(
                    model="whisper-1",
                    file=audio_file,
                    language=language,
                    response_format="verbose_json"
                )
            
            logger.info("✓ Transcription completed successfully")
            
            # Parse response
            result = {
                "text": transcript.text,
                "segments": []
            }
            
            # Extract segments if available
            if hasattr(transcript, 'segments'):
                for seg in transcript.segments:
                    result["segments"].append({
                        "start": seg.get("start", 0),
                        "end": seg.get("end", 0),
                        "text": seg.get("text", ""),
                        "confidence": seg.get("confidence", 1.0)
                    })
            
            return result
            
        except FileNotFoundError:
            logger.error(f"Audio file not found: {audio_path}")
            raise TranscriptionError(
                "Audio file not found",
                detail=f"File: {audio_path}"
            )
        except Exception as e:
            logger.error(f"Transcription error: {e}")
            raise TranscriptionError(
                "Failed to transcribe audio",
                detail=str(e)
            )


class ClipDetectionService:
    """
    Service for AI-driven clip moment detection.
    
    Uses Claude API to analyze transcripts and identify viral moments.
    """
    
    def __init__(self, use_claude: bool = True):
        """
        Initialize clip detection service.
        
        Args:
            use_claude: Whether to use Anthropic Claude (True) or OpenAI GPT (False)
        """
        self.use_claude = use_claude
        
        if use_claude:
            if not settings.ANTHROPIC_API_KEY:
                raise ConfigurationError(
                    "Anthropic API key not configured",
                    detail="Set ANTHROPIC_API_KEY environment variable"
                )
            
            try:
                import anthropic
                self.client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
            except ImportError:
                raise ConfigurationError(
                    "anthropic library not installed",
                    detail="Run: pip install anthropic"
                )
        else:
            if not settings.OPENAI_API_KEY:
                raise ConfigurationError(
                    "OpenAI API key not configured",
                    detail="Set OPENAI_API_KEY environment variable"
                )
            
            try:
                import openai
                self.client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
            except ImportError:
                raise ConfigurationError(
                    "openai library not installed",
                    detail="Run: pip install openai"
                )
    
    def analyze_transcript(
        self,
        transcript_text: str,
        transcript_segments: List[Dict[str, Any]],
        video_duration: float
    ) -> List[Dict[str, Any]]:
        """
        Analyze transcript to identify viral clip moments.
        
        Args:
            transcript_text: Full transcript text
            transcript_segments: List of transcript segments with timing
            video_duration: Total video duration in seconds
            
        Returns:
            List of detected clip moments with metadata:
            [
                {
                    "title": "Viral Title",
                    "seo_title": "SEO Title",
                    "reason": "Why this is viral",
                    "moment_type": "viral|funny|educational|emotional|surprising|engaging",
                    "start_time": 120.5,
                    "end_time": 175.2,
                    "confidence": 0.95
                }
            ]
            
        Raises:
            AIAnalysisError: If analysis fails
        """
        try:
            # Build prompt for AI analysis
            prompt = self._build_analysis_prompt(
                transcript_text,
                transcript_segments,
                video_duration
            )
            
            logger.info("Analyzing transcript for viral moments")
            
            # Call appropriate API
            if self.use_claude:
                response = self._analyze_with_claude(prompt)
            else:
                response = self._analyze_with_gpt(prompt)
            
            # Parse response
            clips = self._parse_clip_response(response)
            
            logger.info(f"✓ Detected {len(clips)} viral moments")
            
            return clips
            
        except Exception as e:
            logger.error(f"AI analysis error: {e}")
            raise AIAnalysisError(
                "Failed to analyze transcript",
                detail=str(e)
            )
    
    def _build_analysis_prompt(
        self,
        transcript_text: str,
        transcript_segments: List[Dict[str, Any]],
        video_duration: float
    ) -> str:
        """Build the analysis prompt for the AI model."""
        
        prompt = f"""
Analyze this video transcript and identify the most viral-worthy clips.

VIDEO DURATION: {video_duration:.1f} seconds

TRANSCRIPT:
{transcript_text}

SEGMENT TIMINGS (for reference):
{self._format_segments(transcript_segments)}

REQUIREMENTS:
1. Identify 5-10 viral clip moments from this video
2. Each clip should be 20-90 seconds long
3. Include setup and payoff (don't cut mid-thought)
4. Focus on:
   - Engaging/captivating moments
   - Funny or humorous content
   - Educational value
   - Emotional impact
   - Surprising revelations
   - Viral-worthy insights

For EACH clip, provide:
- start_time: Timestamp in seconds (float)
- end_time: Timestamp in seconds (float)
- moment_type: One of [engaging, funny, educational, emotional, surprising, viral]
- reason: Why this moment is viral-worthy (2-3 sentences)
- title: A catchy, viral-focused title
- seo_title: An SEO-optimized title with keywords

RESPONSE FORMAT:
Return ONLY a valid JSON array with no additional text or markdown:
[
  {{
    "start_time": 120.5,
    "end_time": 175.2,
    "moment_type": "viral",
    "reason": "Unexpected revelation about...",
    "title": "Mind-Blowing Discovery That Changes Everything",
    "seo_title": "Discovery 2024 | Game-Changing Insight"
  }}
]

IMPORTANT: Return ONLY valid JSON, no markdown, no code blocks, no explanations.
"""
        return prompt
    
    def _format_segments(self, segments: List[Dict[str, Any]]) -> str:
        """Format segments for the prompt."""
        if not segments:
            return "No segments available"
        
        formatted = []
        for seg in segments[:50]:  # Limit to first 50 segments for token efficiency
            formatted.append(f"[{seg['start']:.1f}s-{seg['end']:.1f}s] {seg['text'][:100]}")
        
        return "\n".join(formatted)
    
    def _analyze_with_claude(self, prompt: str) -> str:
        """Analyze transcript using Claude API."""
        try:
            message = self.client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=4096,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            return message.content[0].text
            
        except Exception as e:
            logger.error(f"Claude API error: {e}")
            raise
    
    def _analyze_with_gpt(self, prompt: str) -> str:
        """Analyze transcript using OpenAI GPT API."""
        try:
            response = self.client.chat.completions.create(
                model="gpt-4-turbo",
                max_tokens=4096,
                temperature=0.7,
                messages=[
                    {"role": "user", "content": prompt}
                ]
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"OpenAI API error: {e}")
            raise
    
    def _parse_clip_response(self, response: str) -> List[Dict[str, Any]]:
        """
        Parse AI response to extract clip moments.
        
        Args:
            response: Raw response from AI model
            
        Returns:
            List of parsed clip moments
        """
        try:
            # Try to extract JSON from response
            # AI might include markdown code blocks
            json_str = response
            
            # Remove markdown code blocks if present
            if "```json" in json_str:
                json_str = json_str.split("```json")[1].split("```")[0]
            elif "```" in json_str:
                json_str = json_str.split("```")[1].split("```")[0]
            
            json_str = json_str.strip()
            
            # Parse JSON
            clips = json.loads(json_str)
            
            # Validate and normalize clips
            validated_clips = []
            for clip in clips:
                try:
                    start = float(clip.get("start_time", 0))
                    end = float(clip.get("end_time", 0))
                    duration = end - start
                    
                    # Validate duration
                    if duration < settings.MIN_CLIP_DURATION:
                        logger.warning(f"Clip too short ({duration:.1f}s), skipping")
                        continue
                    if duration > settings.MAX_CLIP_DURATION:
                        logger.warning(f"Clip too long ({duration:.1f}s), skipping")
                        continue
                    
                    validated_clips.append({
                        "start_time": start,
                        "end_time": end,
                        "moment_type": clip.get("moment_type", "viral"),
                        "reason": clip.get("reason", ""),
                        "title": clip.get("title", "Untitled"),
                        "seo_title": clip.get("seo_title", clip.get("title", "Untitled")),
                        "duration": duration
                    })
                except (ValueError, KeyError) as e:
                    logger.warning(f"Failed to validate clip: {e}")
                    continue
            
            # Ensure we have a reasonable number of clips
            target_count = settings.TARGET_CLIP_COUNT
            if len(validated_clips) < settings.MIN_CLIP_COUNT:
                logger.warning(f"Only {len(validated_clips)} clips found, below minimum {settings.MIN_CLIP_COUNT}")
            
            # Return up to MAX_CLIP_COUNT clips
            return validated_clips[:settings.MAX_CLIP_COUNT]
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse AI response as JSON: {e}")
            logger.debug(f"Raw response: {response[:500]}")
            raise AIAnalysisError(
                "Failed to parse AI response",
                detail="Response was not valid JSON"
            )


def generate_titles_for_clips(
    clips: List[Dict[str, Any]]
) -> List[Dict[str, Any]]:
    """
    Generate or enhance titles for clips using OpenAI.
    
    If clips already have titles, this can enhance them.
    
    Args:
        clips: List of clips to enhance
        
    Returns:
        Clips with enhanced titles
    """
    if not settings.OPENAI_API_KEY:
        logger.warning("OpenAI API key not set, skipping title enhancement")
        return clips
    
    try:
        import openai
        client = openai.OpenAI(api_key=settings.OPENAI_API_KEY)
        
        enhanced_clips = []
        
        for clip in clips:
            try:
                # If title is generic, enhance it
                if len(clip.get("title", "")) < 10:
                    prompt = f"""
Create a catchy, viral-worthy title for this clip.
Context: {clip.get('reason', '')}

Return ONLY the title text, nothing else.
"""
                    
                    response = client.chat.completions.create(
                        model="gpt-3.5-turbo",
                        max_tokens=100,
                        messages=[{"role": "user", "content": prompt}]
                    )
                    
                    clip["title"] = response.choices[0].message.content.strip()
                
                enhanced_clips.append(clip)
                
            except Exception as e:
                logger.warning(f"Failed to enhance clip title: {e}")
                enhanced_clips.append(clip)
        
        return enhanced_clips
        
    except Exception as e:
        logger.warning(f"Title enhancement failed: {e}")
        return clips
