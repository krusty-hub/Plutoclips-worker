"""
Video processing orchestration service.

Coordinates the entire workflow: upload, transcription, analysis,
clip generation, caption creation, and file management.
"""

import logging
import uuid
from pathlib import Path
from datetime import datetime
from typing import List, Dict, Any, Optional

from app.core.config import settings
from app.core.exceptions import VideoProcessingError, ResourceNotFoundError
from app.database.sqlite import (
    JobRepository,
    ClipRepository,
    TranscriptRepository,
    ProcessingHistoryRepository,
)
from app.storage.local import LocalStorage
from app.utils import ffmpeg, captions
from app.services.ai import TranscriptionService, ClipDetectionService

logger = logging.getLogger(__name__)


class VideoProcessingService:
    """
    Main orchestration service for video processing pipeline.
    
    Handles:
    1. Video validation and storage
    2. Audio extraction
    3. Transcription via OpenAI Whisper
    4. AI-driven clip detection via Claude/GPT
    5. Clip cutting with FFmpeg
    6. Caption generation
    7. Result aggregation
    """
    
    def __init__(self):
        """Initialize service with dependencies."""
        self.storage = LocalStorage(base_path=settings.UPLOAD_DIR)
        self.transcription_service = TranscriptionService()
        self.clip_detection_service = ClipDetectionService(use_claude=True)
        self.job_repo = JobRepository()
        self.clip_repo = ClipRepository()
        self.transcript_repo = TranscriptRepository()
        self.history_repo = ProcessingHistoryRepository()
    
    # ========================================================================
    # Job Management
    # ========================================================================
    
    def create_job(self, original_filename: str, file_path: str) -> str:
        """
        Create a new processing job.
        
        Args:
            original_filename: Original uploaded filename
            file_path: Path to uploaded video file
            
        Returns:
            Job ID (UUID)
        """
        job_id = str(uuid.uuid4())
        
        self.job_repo.create_job(
            job_id=job_id,
            original_filename=original_filename,
            file_path=file_path,
            status="uploaded"
        )
        
        logger.info(f"✓ Job created: {job_id}")
        return job_id
    
    def get_job_status(self, job_id: str) -> Dict[str, Any]:
        """
        Get job status and details.
        
        Args:
            job_id: Job identifier
            
        Returns:
            Job record as dictionary
            
        Raises:
            ResourceNotFoundError: If job not found
        """
        job = self.job_repo.get_job(job_id)
        
        if not job:
            raise ResourceNotFoundError(f"Job not found: {job_id}")
        
        return job
    
    # ========================================================================
    # Processing Pipeline
    # ========================================================================
    
    async def process_video(self, job_id: str) -> None:
        """
        Execute complete video processing pipeline.
        
        Steps:
        1. Validate video
        2. Extract audio
        3. Transcribe audio
        4. Analyze for viral moments
        5. Generate clips
        6. Create captions
        7. Generate thumbnails
        8. Mark job complete
        
        Args:
            job_id: Job identifier
            
        Raises:
            VideoProcessingError: If any processing step fails
        """
        try:
            logger.info(f"Starting video processing: {job_id}")
            
            # Get job details
            job = self.get_job_status(job_id)
            video_path = job["file_path"]
            
            # Update status
            self.job_repo.update_job_status(job_id, "processing", progress=5)
            
            # Step 1: Validate video
            logger.info("Step 1/8: Validating video")
            self._validate_video(video_path)
            video_info = ffmpeg.get_video_info(video_path)
            video_duration = video_info["duration"]
            self.job_repo.update_job_status(
                job_id,
                "processing",
                progress=10,
                video_duration=video_duration
            )
            self.history_repo.log_step(job_id, "validation", "completed")
            
            # Step 2: Extract audio
            logger.info("Step 2/8: Extracting audio")
            audio_path = await self._extract_audio(job_id, video_path)
            self.job_repo.update_job_status(job_id, "transcribing", progress=20)
            self.history_repo.log_step(job_id, "audio_extraction", "completed")
            
            # Step 3: Transcribe
            logger.info("Step 3/8: Transcribing audio")
            transcript_data = await self._transcribe_audio(job_id, audio_path)
            self.job_repo.update_job_status(job_id, "analyzing", progress=40)
            self.history_repo.log_step(job_id, "transcription", "completed")
            
            # Step 4: Analyze for clips
            logger.info("Step 4/8: Analyzing for viral moments")
            clips = await self._analyze_transcript(
                job_id,
                transcript_data,
                video_duration
            )
            self.job_repo.update_job_status(job_id, "generating", progress=50)
            self.history_repo.log_step(job_id, "analysis", "completed")
            
            # Step 5: Generate clips
            logger.info("Step 5/8: Generating clips")
            generated_clips = await self._generate_clips(
                job_id,
                video_path,
                clips
            )
            self.job_repo.update_job_status(job_id, "generating", progress=70)
            self.history_repo.log_step(job_id, "clip_generation", "completed")
            
            # Step 6: Create captions
            logger.info("Step 6/8: Creating captions")
            await self._create_captions(job_id, transcript_data, clips)
            self.job_repo.update_job_status(job_id, "generating", progress=80)
            self.history_repo.log_step(job_id, "caption_generation", "completed")
            
            # Step 7: Generate thumbnails
            logger.info("Step 7/8: Generating thumbnails")
            await self._generate_thumbnails(job_id, video_path, clips)
            self.job_repo.update_job_status(job_id, "generating", progress=90)
            self.history_repo.log_step(job_id, "thumbnail_generation", "completed")
            
            # Step 8: Mark complete
            logger.info("Step 8/8: Marking job complete")
            self.job_repo.mark_job_completed(job_id)
            self.history_repo.log_step(job_id, "completion", "completed")
            
            logger.info(f"✓ Video processing completed: {job_id}")
            
        except Exception as e:
            logger.error(f"Video processing failed: {e}")
            self.job_repo.mark_job_failed(job_id, str(e))
            self.history_repo.log_step(job_id, "processing", "failed", error_message=str(e))
            raise
    
    # ========================================================================
    # Pipeline Steps
    # ========================================================================
    
    def _validate_video(self, video_path: str) -> None:
        """
        Validate that file is a valid video.
        
        Args:
            video_path: Path to video file
            
        Raises:
            VideoProcessingError: If validation fails
        """
        if not Path(video_path).exists():
            raise VideoProcessingError(f"Video file not found: {video_path}")
        
        if not ffmpeg.validate_video_file(video_path):
            raise VideoProcessingError("Invalid video file or video has no duration")
        
        logger.info("✓ Video validated successfully")
    
    async def _extract_audio(self, job_id: str, video_path: str) -> str:
        """
        Extract audio track from video.
        
        Args:
            job_id: Job identifier
            video_path: Path to video file
            
        Returns:
            Path to extracted audio file
        """
        job_dir = Path(settings.OUTPUT_DIR) / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        
        audio_path = job_dir / "audio.wav"
        
        ffmpeg.extract_audio(
            video_path,
            str(audio_path),
            audio_codec="aac",
            audio_bitrate="128k"
        )
        
        return str(audio_path)
    
    async def _transcribe_audio(
        self,
        job_id: str,
        audio_path: str
    ) -> Dict[str, Any]:
        """
        Transcribe audio using OpenAI Whisper.
        
        Args:
            job_id: Job identifier
            audio_path: Path to audio file
            
        Returns:
            Transcript data with text and segments
        """
        transcript_data = self.transcription_service.transcribe_audio(audio_path)
        
        # Store transcript in database
        transcript_id = f"trans_{job_id}"
        self.transcript_repo.create_transcript(
            transcript_id=transcript_id,
            job_id=job_id,
            full_text=transcript_data["text"],
            segments=transcript_data["segments"],
            duration=0,  # Will be set from video info
            language="en"
        )
        
        return transcript_data
    
    async def _analyze_transcript(
        self,
        job_id: str,
        transcript_data: Dict[str, Any],
        video_duration: float
    ) -> List[Dict[str, Any]]:
        """
        Analyze transcript for viral moments.
        
        Args:
            job_id: Job identifier
            transcript_data: Transcript with text and segments
            video_duration: Total video duration
            
        Returns:
            List of detected clip moments
        """
        clips = self.clip_detection_service.analyze_transcript(
            transcript_text=transcript_data["text"],
            transcript_segments=transcript_data["segments"],
            video_duration=video_duration
        )
        
        logger.info(f"✓ Detected {len(clips)} viral moments")
        
        return clips
    
    async def _generate_clips(
        self,
        job_id: str,
        video_path: str,
        clips: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """
        Generate video clips from detected moments.
        
        Args:
            job_id: Job identifier
            video_path: Path to original video
            clips: List of clip definitions
            
        Returns:
            List of generated clip records
        """
        job_dir = Path(settings.OUTPUT_DIR) / job_id
        job_dir.mkdir(parents=True, exist_ok=True)
        
        generated_clips = []
        
        for idx, clip in enumerate(clips, start=1):
            clip_id = f"clip_{job_id}_{idx:02d}"
            
            # Create clip file
            clip_filename = f"clip_{idx:02d}.mp4"
            clip_path = job_dir / clip_filename
            
            ffmpeg.cut_clip(
                video_path=video_path,
                output_path=str(clip_path),
                start_time=clip["start_time"],
                end_time=clip["end_time"],
                video_codec=settings.VIDEO_CODEC,
                video_bitrate=settings.VIDEO_BITRATE,
                audio_codec=settings.AUDIO_CODEC,
                audio_bitrate=settings.AUDIO_BITRATE
            )
            
            # Store clip in database
            self.clip_repo.create_clip(
                clip_id=clip_id,
                job_id=job_id,
                clip_index=idx,
                title=clip["title"],
                seo_title=clip.get("seo_title", clip["title"]),
                reason=clip["reason"],
                moment_type=clip["moment_type"],
                start_time=clip["start_time"],
                end_time=clip["end_time"],
                duration=clip["end_time"] - clip["start_time"],
                file_path=str(clip_path)
            )
            
            generated_clips.append({
                **clip,
                "clip_id": clip_id,
                "file_path": str(clip_path)
            })
        
        logger.info(f"✓ Generated {len(generated_clips)} clips")
        
        return generated_clips
    
    async def _create_captions(
        self,
        job_id: str,
        transcript_data: Dict[str, Any],
        clips: List[Dict[str, Any]]
    ) -> None:
        """
        Create SRT caption files for clips.
        
        Args:
            job_id: Job identifier
            transcript_data: Transcript with segments
            clips: List of clips
        """
        job_dir = Path(settings.OUTPUT_DIR) / job_id
        
        for idx, clip in enumerate(clips, start=1):
            # Filter transcript segments for this clip
            clip_segments = [
                s for s in transcript_data.get("segments", [])
                if s.get("start", 0) >= clip["start_time"]
                and s.get("end", 0) <= clip["end_time"]
            ]
            
            if not clip_segments:
                continue
            
            # Create SRT file
            captions_filename = f"clip_{idx:02d}.srt"
            captions_path = job_dir / captions_filename
            
            captions.save_srt_file(
                str(captions_path),
                clip_segments,
                remove_fillers=True
            )
            
            # Update clip record with captions path
            clip_id = f"clip_{job_id}_{idx:02d}"
            self.clip_repo.update_clip_paths(
                clip_id,
                captions_path=str(captions_path)
            )
    
    async def _generate_thumbnails(
        self,
        job_id: str,
        video_path: str,
        clips: List[Dict[str, Any]]
    ) -> None:
        """
        Generate thumbnail images for clips.
        
        Args:
            job_id: Job identifier
            video_path: Path to original video
            clips: List of clips
        """
        job_dir = Path(settings.OUTPUT_DIR) / job_id
        
        for idx, clip in enumerate(clips, start=1):
            # Generate thumbnail at clip start time
            thumbnail_filename = f"clip_{idx:02d}_thumb.jpg"
            thumbnail_path = job_dir / thumbnail_filename
            
            try:
                ffmpeg.generate_thumbnail(
                    video_path=video_path,
                    output_path=str(thumbnail_path),
                    timestamp=clip["start_time"],
                    size="320x180"
                )
                
                # Update clip record with thumbnail path
                clip_id = f"clip_{job_id}_{idx:02d}"
                self.clip_repo.update_clip_paths(
                    clip_id,
                    thumbnail_path=str(thumbnail_path)
                )
                
            except Exception as e:
                logger.warning(f"Failed to generate thumbnail for clip {idx}: {e}")
    
    # ========================================================================
    # Results
    # ========================================================================
    
    def get_clips(self, job_id: str) -> Dict[str, Any]:
        """
        Get all clips for a completed job.
        
        Args:
            job_id: Job identifier
            
        Returns:
            Dictionary with clips data and metadata
            
        Raises:
            ResourceNotFoundError: If job not found
        """
        job = self.get_job_status(job_id)
        clips = self.clip_repo.get_clips_by_job(job_id)
        
        # Convert to response format
        clip_list = []
        for clip in clips:
            clip_list.append({
                "clip_id": clip["id"],
                "title": clip["title"],
                "seo_title": clip["seo_title"],
                "url": f"/api/v1/download/{Path(clip['file_path']).name}" if clip["file_path"] else None,
                "duration": clip["duration"],
                "thumbnail_url": f"/api/v1/download/{Path(clip['thumbnail_path']).name}" if clip["thumbnail_path"] else None,
                "captions_url": f"/api/v1/download/{Path(clip['captions_path']).name}" if clip["captions_path"] else None,
                "moment_type": clip["moment_type"],
                "reason": clip["reason"]
            })
        
        return {
            "job_id": job_id,
            "status": job["status"],
            "total_clips": len(clip_list),
            "clips": clip_list,
            "video_duration": job.get("video_duration", 0),
            "created_at": job["created_at"],
            "completed_at": job.get("completed_at")
        }
