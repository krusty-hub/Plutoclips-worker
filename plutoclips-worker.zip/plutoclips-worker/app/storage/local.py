"""
Storage abstraction layer for file operations.

Provides a unified interface for storage operations to support
multiple backends (local, S3, R2) in the future.
"""

from abc import ABC, abstractmethod
from pathlib import Path
from typing import Optional, BinaryIO
import shutil
import os

from app.core.exceptions import StorageError
from app.core.logger import get_logger

logger = get_logger(__name__)


class StorageBackend(ABC):
    """Abstract base class for storage backends."""
    
    @abstractmethod
    async def save_file(self, file_path: str, content: bytes) -> str:
        """Save file and return access path."""
        pass
    
    @abstractmethod
    async def get_file(self, file_path: str) -> bytes:
        """Retrieve file content."""
        pass
    
    @abstractmethod
    async def delete_file(self, file_path: str) -> None:
        """Delete a file."""
        pass
    
    @abstractmethod
    async def file_exists(self, file_path: str) -> bool:
        """Check if file exists."""
        pass
    
    @abstractmethod
    def get_url(self, file_path: str) -> str:
        """Get public URL for file."""
        pass


class LocalStorage(StorageBackend):
    """
    Local filesystem storage backend.
    
    Stores files in local directories. Suitable for development
    and can be swapped for cloud storage in production.
    """
    
    def __init__(self, base_path: str = "uploads"):
        """
        Initialize local storage.
        
        Args:
            base_path: Base directory for storage
        """
        self.base_path = Path(base_path)
        self.base_path.mkdir(parents=True, exist_ok=True)
        logger.info(f"LocalStorage initialized: {self.base_path}")
    
    async def save_file(self, file_path: str, content: bytes) -> str:
        """
        Save file to local filesystem.
        
        Args:
            file_path: Relative file path
            content: File content as bytes
            
        Returns:
            Full path to saved file
            
        Raises:
            StorageError: If save operation fails
        """
        try:
            full_path = self.base_path / file_path
            full_path.parent.mkdir(parents=True, exist_ok=True)
            
            with open(full_path, 'wb') as f:
                f.write(content)
            
            logger.info(f"File saved: {full_path}")
            return str(full_path)
            
        except Exception as e:
            logger.error(f"Failed to save file {file_path}: {e}")
            raise StorageError(f"Failed to save file: {str(e)}")
    
    async def save_file_from_path(self, source_path: str, dest_path: str) -> str:
        """
        Copy file from source to destination.
        
        Args:
            source_path: Source file path
            dest_path: Destination relative path
            
        Returns:
            Full path to saved file
            
        Raises:
            StorageError: If copy operation fails
        """
        try:
            full_dest = self.base_path / dest_path
            full_dest.parent.mkdir(parents=True, exist_ok=True)
            
            shutil.copy2(source_path, full_dest)
            logger.info(f"File copied: {source_path} -> {full_dest}")
            return str(full_dest)
            
        except Exception as e:
            logger.error(f"Failed to copy file: {e}")
            raise StorageError(f"Failed to copy file: {str(e)}")
    
    async def get_file(self, file_path: str) -> bytes:
        """
        Retrieve file content.
        
        Args:
            file_path: Relative file path
            
        Returns:
            File content as bytes
            
        Raises:
            StorageError: If read operation fails
        """
        try:
            full_path = self.base_path / file_path
            
            if not full_path.exists():
                raise StorageError(f"File not found: {file_path}")
            
            with open(full_path, 'rb') as f:
                return f.read()
                
        except Exception as e:
            logger.error(f"Failed to read file {file_path}: {e}")
            raise StorageError(f"Failed to read file: {str(e)}")
    
    async def delete_file(self, file_path: str) -> None:
        """
        Delete a file.
        
        Args:
            file_path: Relative file path
            
        Raises:
            StorageError: If delete operation fails
        """
        try:
            full_path = self.base_path / file_path
            
            if full_path.exists():
                full_path.unlink()
                logger.info(f"File deleted: {full_path}")
            else:
                logger.warning(f"File not found for deletion: {file_path}")
                
        except Exception as e:
            logger.error(f"Failed to delete file {file_path}: {e}")
            raise StorageError(f"Failed to delete file: {str(e)}")
    
    async def file_exists(self, file_path: str) -> bool:
        """
        Check if file exists.
        
        Args:
            file_path: Relative file path
            
        Returns:
            True if file exists, False otherwise
        """
        full_path = self.base_path / file_path
        return full_path.exists()
    
    def get_url(self, file_path: str) -> str:
        """
        Get URL for file.
        
        For local storage, returns a relative path that can be served
        by the API. Format: /api/v1/download/{file_path}
        
        Args:
            file_path: Relative file path
            
        Returns:
            URL path
        """
        # Remove any base path prefix for URL
        if str(file_path).startswith(str(self.base_path)):
            url_path = str(file_path)[len(str(self.base_path)):].lstrip('/')
        else:
            url_path = file_path
        
        return f"/api/v1/download/{url_path}"
    
    async def delete_directory(self, dir_path: str) -> None:
        """
        Delete an entire directory.
        
        Args:
            dir_path: Relative directory path
            
        Raises:
            StorageError: If delete operation fails
        """
        try:
            full_path = self.base_path / dir_path
            
            if full_path.exists() and full_path.is_dir():
                shutil.rmtree(full_path)
                logger.info(f"Directory deleted: {full_path}")
            
        except Exception as e:
            logger.error(f"Failed to delete directory {dir_path}: {e}")
            raise StorageError(f"Failed to delete directory: {str(e)}")
    
    async def get_directory_size(self, dir_path: str) -> int:
        """
        Get total size of directory in bytes.
        
        Args:
            dir_path: Relative directory path
            
        Returns:
            Total size in bytes
        """
        try:
            full_path = self.base_path / dir_path
            
            if not full_path.exists():
                return 0
            
            total_size = 0
            for dirpath, dirnames, filenames in os.walk(full_path):
                for filename in filenames:
                    filepath = os.path.join(dirpath, filename)
                    if os.path.exists(filepath):
                        total_size += os.path.getsize(filepath)
            
            return total_size
            
        except Exception as e:
            logger.error(f"Failed to get directory size: {e}")
            return 0


# ============================================================================
# S3-compatible backend (stub for future implementation)
# ============================================================================

class S3Storage(StorageBackend):
    """
    S3-compatible storage backend (e.g., AWS S3, Cloudflare R2).
    
    This is a stub implementation. Complete in production with boto3.
    """
    
    def __init__(self, bucket: str, region: str, access_key: str, secret_key: str):
        """Initialize S3 storage."""
        self.bucket = bucket
        self.region = region
        # TODO: Initialize boto3 client
        logger.info(f"S3Storage configured: {bucket} ({region})")
    
    async def save_file(self, file_path: str, content: bytes) -> str:
        """Save file to S3."""
        raise NotImplementedError("S3Storage not yet implemented")
    
    async def get_file(self, file_path: str) -> bytes:
        """Get file from S3."""
        raise NotImplementedError("S3Storage not yet implemented")
    
    async def delete_file(self, file_path: str) -> None:
        """Delete file from S3."""
        raise NotImplementedError("S3Storage not yet implemented")
    
    async def file_exists(self, file_path: str) -> bool:
        """Check if file exists in S3."""
        raise NotImplementedError("S3Storage not yet implemented")
    
    def get_url(self, file_path: str) -> str:
        """Get S3 URL for file."""
        return f"https://{self.bucket}.s3.{self.region}.amazonaws.com/{file_path}"


# Create default storage instance
def get_storage() -> StorageBackend:
    """
    Get storage backend instance.
    
    Returns:
        StorageBackend: Configured storage backend
    """
    # For MVP, always use local storage
    # Future: make this configurable based on environment
    return LocalStorage(base_path="uploads")
