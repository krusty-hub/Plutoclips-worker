"""
Captions and SRT file generation utilities.

Handles creation and manipulation of SRT subtitle files,
including filler word removal and timing-aware cleaning.
"""

import re
from typing import List, Dict, Any, Tuple
from pathlib import Path
import logging

from app.core.exceptions import VideoProcessingError

logger = logging.getLogger(__name__)


# Common filler words to remove from captions
FILLER_WORDS = {
    "um", "uh", "umm", "uhh",
    "like", "kinda", "kind of",
    "you know", "you know what",
    "sort of", "sorta",
    "literally",
    "basically",
    "honestly",
    "anyway",
    "so",
    "uh-huh",
    "mm-hmm",
    "err", "erm",
}


def _is_filler_word(word: str) -> bool:
    """
    Check if a word is a filler word.
    
    Args:
        word: Word to check
        
    Returns:
        True if word is a filler word
    """
    word_lower = word.lower().strip(".,!?;:")
    return word_lower in FILLER_WORDS


def clean_text(text: str, remove_fillers: bool = True) -> str:
    """
    Clean caption text by removing filler words and extra spaces.
    
    Args:
        text: Text to clean
        remove_fillers: Whether to remove filler words
        
    Returns:
        Cleaned text
    """
    if not text:
        return ""
    
    # Remove extra whitespace
    text = " ".join(text.split())
    
    if not remove_fillers:
        return text
    
    # Remove filler words
    words = text.split()
    cleaned_words = [w for w in words if not _is_filler_word(w)]
    
    result = " ".join(cleaned_words)
    
    # Ensure proper spacing around punctuation
    result = re.sub(r'\s+([.,!?;:])', r'\1', result)
    
    return result


def format_timestamp(seconds: float) -> str:
    """
    Format seconds as SRT timestamp (HH:MM:SS,mmm).
    
    Args:
        seconds: Time in seconds
        
    Returns:
        Formatted timestamp string
    """
    hours = int(seconds // 3600)
    minutes = int((seconds % 3600) // 60)
    secs = int(seconds % 60)
    millis = int((seconds % 1) * 1000)
    
    return f"{hours:02d}:{minutes:02d}:{secs:02d},{millis:03d}"


def parse_timestamp(timestamp: str) -> float:
    """
    Parse SRT timestamp to seconds.
    
    Args:
        timestamp: Formatted timestamp (HH:MM:SS,mmm)
        
    Returns:
        Time in seconds
    """
    # Handle both comma and period as decimal separator
    timestamp = timestamp.replace(",", ".")
    
    parts = timestamp.split(":")
    hours = int(parts[0])
    minutes = int(parts[1])
    seconds = float(parts[2])
    
    return hours * 3600 + minutes * 60 + seconds


def create_srt_content(segments: List[Dict[str, Any]], remove_fillers: bool = True) -> str:
    """
    Create SRT file content from transcript segments.
    
    Args:
        segments: List of segments with 'start', 'end', and 'text' keys
        remove_fillers: Whether to remove filler words
        
    Returns:
        SRT file content as string
    """
    srt_lines = []
    
    for idx, segment in enumerate(segments, start=1):
        start = segment.get("start", 0)
        end = segment.get("end", 0)
        text = segment.get("text", "")
        
        if not text:
            continue
        
        # Clean text
        cleaned_text = clean_text(text, remove_fillers=remove_fillers)
        
        if not cleaned_text:
            continue
        
        # Format SRT entry
        srt_lines.append(str(idx))
        srt_lines.append(f"{format_timestamp(start)} --> {format_timestamp(end)}")
        srt_lines.append(cleaned_text)
        srt_lines.append("")  # Blank line between entries
    
    return "\n".join(srt_lines)


def save_srt_file(
    output_path: str,
    segments: List[Dict[str, Any]],
    remove_fillers: bool = True
) -> None:
    """
    Save SRT subtitle file.
    
    Args:
        output_path: Path to save SRT file
        segments: List of transcript segments
        remove_fillers: Whether to remove filler words
        
    Raises:
        VideoProcessingError: If save fails
    """
    try:
        srt_content = create_srt_content(segments, remove_fillers=remove_fillers)
        
        output_file = Path(output_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(srt_content)
        
        logger.info(f"✓ SRT file saved: {output_path}")
        
    except Exception as e:
        logger.error(f"Failed to save SRT file: {e}")
        raise VideoProcessingError(f"Failed to save captions: {str(e)}")


def load_srt_file(srt_path: str) -> List[Dict[str, Any]]:
    """
    Load and parse SRT file.
    
    Args:
        srt_path: Path to SRT file
        
    Returns:
        List of subtitle entries with index, start, end, and text
        
    Raises:
        VideoProcessingError: If file cannot be read
    """
    try:
        segments = []
        
        with open(srt_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Split by double newlines to get subtitle blocks
        blocks = content.strip().split('\n\n')
        
        for block in blocks:
            lines = block.strip().split('\n')
            
            if len(lines) < 3:
                continue
            
            try:
                # Line 1: Index
                index = int(lines[0])
                
                # Line 2: Timestamps
                timestamps = lines[1].split(' --> ')
                start = parse_timestamp(timestamps[0].strip())
                end = parse_timestamp(timestamps[1].strip())
                
                # Lines 3+: Text
                text = " ".join(lines[2:])
                
                segments.append({
                    "index": index,
                    "start": start,
                    "end": end,
                    "text": text
                })
            except (ValueError, IndexError) as e:
                logger.warning(f"Failed to parse subtitle block: {e}")
                continue
        
        return segments
        
    except Exception as e:
        logger.error(f"Failed to load SRT file: {e}")
        raise VideoProcessingError(f"Failed to load captions: {str(e)}")


def merge_subtitle_segments(
    segments: List[Dict[str, Any]],
    max_lines: int = 2
) -> List[Dict[str, Any]]:
    """
    Merge short subtitle segments to reduce crowding.
    
    Combines consecutive segments if they fit within line count,
    making subtitles easier to read.
    
    Args:
        segments: List of subtitle segments
        max_lines: Maximum lines per subtitle
        
    Returns:
        List of merged segments
    """
    if not segments:
        return []
    
    merged = []
    current_segment = None
    
    for segment in segments:
        if current_segment is None:
            current_segment = segment.copy()
        else:
            # Check if we should merge
            text_lines = (current_segment.get("text", "") + " " + segment.get("text", "")).split('\n')
            
            if len(text_lines) <= max_lines:
                # Merge segments
                current_segment["end"] = segment["end"]
                current_segment["text"] += " " + segment["text"]
            else:
                # Save current and start new
                merged.append(current_segment)
                current_segment = segment.copy()
    
    if current_segment:
        merged.append(current_segment)
    
    # Renumber indices
    for idx, segment in enumerate(merged, start=1):
        segment["index"] = idx
    
    return merged


def adjust_subtitle_timing(
    segments: List[Dict[str, Any]],
    offset_seconds: float
) -> List[Dict[str, Any]]:
    """
    Adjust subtitle timing by a fixed offset.
    
    Args:
        segments: List of subtitle segments
        offset_seconds: Time offset in seconds
        
    Returns:
        List of segments with adjusted timing
    """
    adjusted = []
    
    for segment in segments:
        new_segment = segment.copy()
        new_segment["start"] = max(0, segment.get("start", 0) + offset_seconds)
        new_segment["end"] = max(0, segment.get("end", 0) + offset_seconds)
        adjusted.append(new_segment)
    
    return adjusted


def extract_subtitle_text(srt_path: str) -> str:
    """
    Extract all text from an SRT file as a single string.
    
    Args:
        srt_path: Path to SRT file
        
    Returns:
        Combined text from all subtitles
        
    Raises:
        VideoProcessingError: If file cannot be read
    """
    try:
        segments = load_srt_file(srt_path)
        texts = [seg.get("text", "") for seg in segments]
        return " ".join(texts)
    except Exception as e:
        logger.error(f"Failed to extract subtitle text: {e}")
        raise VideoProcessingError(f"Failed to extract subtitle text: {str(e)}")
