"""
FFmpeg utility functions for video processing.

Provides clean, reusable services for common video operations:
- Audio extraction
- Video clipping
- Caption burning
- Thumbnail generation
- Format conversion
"""

import subprocess
import json
import os
from pathlib import Path
from typing import Optional, Tuple, Dict, Any
import logging

from app.core.exceptions import VideoProcessingError
from app.core.config import settings

logger = logging.getLogger(__name__)


class FFmpegError(VideoProcessingError):
    """FFmpeg-specific processing error."""
    pass


def _run_ffmpeg(
    command: list,
    description: str = "FFmpeg operation",
    timeout: int = 300
) -> str:
    """
    Run FFmpeg command safely.
    
    Args:
        command: FFmpeg command as list
        description: Description of operation for logging
        timeout: Command timeout in seconds
        
    Returns:
        FFmpeg output/stderr
        
    Raises:
        FFmpegError: If command fails
    """
    try:
        logger.info(f"Running FFmpeg: {description}")
        logger.debug(f"Command: {' '.join(command)}")
        
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False
        )
        
        if result.returncode != 0:
            error_msg = result.stderr or result.stdout
            logger.error(f"FFmpeg error: {error_msg}")
            raise FFmpegError(
                f"FFmpeg failed for {description}",
                detail=f"Return code: {result.returncode}"
            )
        
        logger.info(f"✓ Completed: {description}")
        return result.stdout + result.stderr
        
    except subprocess.TimeoutExpired:
        raise FFmpegError(
            f"FFmpeg timeout for {description}",
            detail=f"Operation exceeded {timeout} seconds"
        )
    except FileNotFoundError:
        raise FFmpegError(
            "FFmpeg not found",
            detail="FFmpeg must be installed and in PATH"
        )
    except Exception as e:
        raise FFmpegError(
            f"FFmpeg error for {description}",
            detail=str(e)
        )


def get_video_info(video_path: str) -> Dict[str, Any]:
    """
    Get detailed video information using ffprobe.
    
    Args:
        video_path: Path to video file
        
    Returns:
        Dictionary with video metadata (duration, resolution, codecs, etc.)
        
    Raises:
        FFmpegError: If probe fails
    """
    try:
        command = [
            "ffprobe",
            "-v", "error",
            "-show_format",
            "-show_streams",
            "-of", "json",
            video_path
        ]
        
        result = subprocess.run(
            command,
            capture_output=True,
            text=True,
            timeout=60,
            check=False
        )
        
        if result.returncode != 0:
            raise FFmpegError(f"Failed to probe video: {video_path}")
        
        probe_data = json.loads(result.stdout)
        
        # Extract relevant information
        format_data = probe_data.get("format", {})
        streams = probe_data.get("streams", [])
        
        video_stream = next((s for s in streams if s["codec_type"] == "video"), {})
        audio_stream = next((s for s in streams if s["codec_type"] == "audio"), {})
        
        info = {
            "duration": float(format_data.get("duration", 0)),
            "size": int(format_data.get("size", 0)),
            "bit_rate": int(format_data.get("bit_rate", 0)),
            "video": {
                "codec": video_stream.get("codec_name", "unknown"),
                "width": video_stream.get("width", 0),
                "height": video_stream.get("height", 0),
                "fps": eval(video_stream.get("r_frame_rate", "0/1")) if "r_frame_rate" in video_stream else 0,
                "duration": float(video_stream.get("duration", format_data.get("duration", 0)))
            },
            "audio": {
                "codec": audio_stream.get("codec_name", "unknown"),
                "sample_rate": audio_stream.get("sample_rate", 0),
                "channels": audio_stream.get("channels", 0),
            }
        }
        
        return info
        
    except json.JSONDecodeError:
        raise FFmpegError("Invalid ffprobe output")
    except Exception as e:
        raise FFmpegError(f"Failed to get video info: {str(e)}")


def extract_audio(
    video_path: str,
    audio_path: str,
    audio_codec: str = "aac",
    audio_bitrate: str = "128k"
) -> None:
    """
    Extract audio track from video file.
    
    Args:
        video_path: Path to input video
        audio_path: Path to output audio file
        audio_codec: Audio codec to use
        audio_bitrate: Audio bitrate (e.g., "128k")
        
    Raises:
        FFmpegError: If extraction fails
    """
    command = [
        "ffmpeg",
        "-i", video_path,
        "-q:a", "0",
        "-map", "a",
        audio_path,
        "-y"  # Overwrite output
    ]
    
    _run_ffmpeg(
        command,
        description=f"Extract audio from {Path(video_path).name}",
        timeout=600
    )


def cut_clip(
    video_path: str,
    output_path: str,
    start_time: float,
    end_time: float,
    video_codec: str = "libx264",
    video_bitrate: str = "2500k",
    audio_codec: str = "aac",
    audio_bitrate: str = "128k"
) -> None:
    """
    Cut a clip from a video file.
    
    Args:
        video_path: Path to input video
        output_path: Path to output clip
        start_time: Start time in seconds
        end_time: End time in seconds
        video_codec: Video codec to use
        video_bitrate: Video bitrate
        audio_codec: Audio codec to use
        audio_bitrate: Audio bitrate
        
    Raises:
        FFmpegError: If cutting fails
    """
    # Calculate duration
    duration = end_time - start_time
    
    command = [
        "ffmpeg",
        "-ss", str(start_time),
        "-to", str(end_time),
        "-i", video_path,
        "-c:v", video_codec,
        "-b:v", video_bitrate,
        "-c:a", audio_codec,
        "-b:a", audio_bitrate,
        "-preset", "medium",
        "-y",
        output_path
    ]
    
    _run_ffmpeg(
        command,
        description=f"Cut clip {start_time:.1f}s-{end_time:.1f}s ({duration:.1f}s)",
        timeout=600
    )


def generate_thumbnail(
    video_path: str,
    output_path: str,
    timestamp: float,
    size: str = "320x180"
) -> None:
    """
    Generate thumbnail from video at specific timestamp.
    
    Args:
        video_path: Path to input video
        output_path: Path to output thumbnail
        timestamp: Timestamp for thumbnail in seconds
        size: Thumbnail size (e.g., "320x180")
        
    Raises:
        FFmpegError: If generation fails
    """
    command = [
        "ffmpeg",
        "-ss", str(timestamp),
        "-i", video_path,
        "-vframes", "1",
        "-vf", f"scale={size}",
        "-y",
        output_path
    ]
    
    _run_ffmpeg(
        command,
        description=f"Generate thumbnail from {Path(video_path).name}",
        timeout=60
    )


def add_subtitles_to_video(
    video_path: str,
    subtitle_path: str,
    output_path: str,
    video_codec: str = "libx264",
    video_bitrate: str = "2500k"
) -> None:
    """
    Burn subtitles into video file.
    
    Args:
        video_path: Path to input video
        subtitle_path: Path to SRT subtitle file
        output_path: Path to output video with burned subtitles
        video_codec: Video codec to use
        video_bitrate: Video bitrate
        
    Raises:
        FFmpegError: If burning fails
    """
    # Escape subtitle path for ffmpeg filter
    subtitle_path_escaped = subtitle_path.replace("\\", "/").replace(":", "\\:")
    
    command = [
        "ffmpeg",
        "-i", video_path,
        "-vf", f"subtitles={subtitle_path_escaped}",
        "-c:v", video_codec,
        "-b:v", video_bitrate,
        "-c:a", "aac",
        "-preset", "medium",
        "-y",
        output_path
    ]
    
    _run_ffmpeg(
        command,
        description=f"Add subtitles to {Path(video_path).name}",
        timeout=600
    )


def get_video_duration(video_path: str) -> float:
    """
    Get video duration in seconds.
    
    Args:
        video_path: Path to video file
        
    Returns:
        Duration in seconds
        
    Raises:
        FFmpegError: If duration cannot be determined
    """
    try:
        info = get_video_info(video_path)
        return info["duration"]
    except Exception as e:
        raise FFmpegError(f"Failed to get video duration: {str(e)}")


def validate_video_file(video_path: str) -> bool:
    """
    Validate that a file is a valid video.
    
    Args:
        video_path: Path to video file
        
    Returns:
        True if valid video, False otherwise
    """
    try:
        info = get_video_info(video_path)
        return info.get("duration", 0) > 0 and info["video"].get("duration", 0) > 0
    except Exception:
        return False


def get_video_resolution(video_path: str) -> Tuple[int, int]:
    """
    Get video resolution (width, height).
    
    Args:
        video_path: Path to video file
        
    Returns:
        Tuple of (width, height)
        
    Raises:
        FFmpegError: If resolution cannot be determined
    """
    try:
        info = get_video_info(video_path)
        width = info["video"].get("width", 1920)
        height = info["video"].get("height", 1080)
        return (width, height)
    except Exception as e:
        raise FFmpegError(f"Failed to get resolution: {str(e)}")
